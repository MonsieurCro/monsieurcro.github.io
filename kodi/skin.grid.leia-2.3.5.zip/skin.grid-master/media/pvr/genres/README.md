Genre Numbers set internally by Kodi


0 = other/unknown

16 = moviedrama

32 = news

48 = show

64 = sports

80 = child

96 = music

112 = arts

128 = social

144 = science

160 = hobby

176 = special

192 = other/unknown

208 = other/unknown

224 = other/unknown

240 = other/unknown

256 = use genre string from the backend
